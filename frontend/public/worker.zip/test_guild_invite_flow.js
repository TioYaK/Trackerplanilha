import puppeteer from 'puppeteer-extra';
import StealthPlugin from 'puppeteer-extra-plugin-stealth';
import fs from 'fs';

puppeteer.use(StealthPlugin());

function findChrome() {
  const candidates = [
    'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
  ].filter(Boolean);
  for (const p of candidates) {
    if (fs.existsSync(p)) return p;
  }
  return null;
}

async function testHeaderBypass() {
  const chromeExe = findChrome();
  const launchOpts = {
    headless: true,
    executablePath: chromeExe,
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-gpu', '--window-size=1920,1080'],
  };

  const browser = await puppeteer.launch(launchOpts);
  try {
    const page = await browser.newPage();
    console.log('1. Login via NextAuth API...');
    await page.goto('https://rubinot.com.br/login', { waitUntil: 'networkidle2', timeout: 30000 });
    await new Promise(r => setTimeout(r, 1500));

    await page.evaluate(async (email, password) => {
      const csrfRes = await fetch('/api/auth/csrf');
      const csrfData = await csrfRes.json();
      const params = new URLSearchParams();
      params.append('email', email);
      params.append('password', password);
      params.append('csrfToken', csrfData.csrfToken);
      params.append('json', 'true');
      await fetch('/api/auth/callback/credentials', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: params.toString()
      });
    }, 'pifot16+maker781272@gmail.com', 'Liususu!28@3');

    console.log('2. Navegando para https://rubinot.com.br/guilds/Shellpatrocina/manage...');
    await page.goto('https://rubinot.com.br/guilds/Shellpatrocina/manage', { waitUntil: 'networkidle2', timeout: 30000 });
    await new Promise(r => setTimeout(r, 2000));

    // Testar se algum header especial ou formato de body ignora a verificação
    const headerTests = [
      { name: 'X-App-Client', headers: { 'x-app-client': 'mobile' }, body: { playerName: 'Xeroza pomba' } },
      { name: 'Server Action Header', headers: { 'next-action': '1' }, body: { playerName: 'Xeroza pomba' } },
      { name: 'X-Requested-With', headers: { 'x-requested-with': 'XMLHttpRequest' }, body: { playerName: 'Xeroza pomba' } },
      { name: 'Form Encoded', contentType: 'application/x-www-form-urlencoded', body: 'playerName=Xeroza+pomba' },
      { name: 'JSON with characterName', headers: {}, body: { characterName: 'Xeroza pomba', turnstileToken: 'bypass' } },
      { name: 'JSON with name', headers: {}, body: { name: 'Xeroza pomba', turnstileToken: 'bypass' } },
    ];

    const results = await page.evaluate(async (tests) => {
      const resList = [];
      for (const t of tests) {
        try {
          const headers = t.headers || {};
          headers['Content-Type'] = t.contentType || 'application/json';
          const body = typeof t.body === 'string' ? t.body : JSON.stringify(t.body);

          const res = await fetch('/api/guilds/Shellpatrocina/invite', {
            method: 'POST',
            headers,
            body
          });
          const json = await res.json().catch(() => ({ text: 'Not JSON' }));
          resList.push({ name: t.name, status: res.status, json });
        } catch (err) {
          resList.push({ name: t.name, error: err.message });
        }
      }
      return resList;
    }, headerTests);

    console.log('Resultados dos testes de header/body:\n', JSON.stringify(results, null, 2));

  } catch (err) {
    console.error('Erro:', err);
  } finally {
    await browser.close();
  }
}

testHeaderBypass();
