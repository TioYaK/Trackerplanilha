import puppeteer from 'puppeteer-extra';
import StealthPlugin from 'puppeteer-extra-plugin-stealth';
import * as cheerio from 'cheerio';
puppeteer.use(StealthPlugin());

(async () => {
  const browser = await puppeteer.launch({headless: true});
  const page = await browser.newPage();
  
  await page.goto('https://rubinot.com.br/killstats');
  
  const selects = await page.$$('select');
  if (selects.length > 0) {
      await selects[0].select('11'); // Auroria
      await page.waitForSelector('table tbody tr', { timeout: 10000 });
      const $ = cheerio.load(await page.content());
      console.log('Killstats Rows:', $('table tbody tr').slice(0, 3).map((i, r) => $(r).text().trim().replace(/\s+/g, ' ')).get());
  }
  await browser.close();
})();
