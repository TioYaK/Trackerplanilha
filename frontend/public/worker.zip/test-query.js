﻿import { supabase } from './src/db.js';

const now = new Date().toISOString();
const crashLimit = new Date();
crashLimit.setMinutes(crashLimit.getMinutes() - 15);
const orQuery = "and(status.eq.PENDING,or(locked_at.is.null,locked_at.lte." + now + ")),and(status.eq.IN_PROGRESS,locked_at.lte." + crashLimit.toISOString() + "))";

async function run() {
  const { data, error } = await supabase.from('task_queue').select('*').or(orQuery);
  console.log('Error:', error);
  console.log('Tasks fetched:', data ? data.map(t => t.task_type) : null);
  process.exit(0);
}
run();
