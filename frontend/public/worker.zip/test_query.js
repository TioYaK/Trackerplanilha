import { supabase } from './src/db.js';

async function testQuery() {
  const now = new Date().toISOString();
  const crashLimit = new Date();
  crashLimit.setMinutes(crashLimit.getMinutes() - 5);
  
  const orQuery = `and(status.eq.PENDING,or(locked_at.is.null,locked_at.lte.${now})),and(status.eq.IN_PROGRESS,locked_at.lte.${crashLimit.toISOString()})`;
  console.log('Query:', orQuery);
  
  const { data, error } = await supabase
    .from('task_queue')
    .select('*')
    .or(orQuery)
    .order('locked_at', { ascending: true, nullsFirst: true })
    .limit(1);
    
  if (error) console.error('Error:', error);
  console.log('Tasks:', JSON.stringify(data, null, 2));
}

testQuery();
