const fs = require('fs');
const cheerio = require('cheerio');
const html = fs.readFileSync('transfers.html', 'utf8');
const $ = cheerio.load(html);
console.log($('*:contains("Former World")').last().html());
