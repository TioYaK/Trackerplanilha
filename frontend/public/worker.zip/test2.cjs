const fs = require('fs');
const cheerio = require('cheerio');
const html = fs.readFileSync('killstats.html', 'utf8');
const $ = cheerio.load(html);
console.log('Killstats Rows:', $('table tbody tr').slice(0, 5).map((i, r) => $(r).text().trim()).get());
