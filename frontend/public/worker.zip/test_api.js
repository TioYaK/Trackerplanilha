import puppeteer from 'puppeteer-extra';
import StealthPlugin from 'puppeteer-extra-plugin-stealth';
puppeteer.use(StealthPlugin());

(async () => {
  const browser = await puppeteer.launch({headless: true});
  const page = await browser.newPage();
  
  await page.goto('https://rubinot.com.br/transfers');
  
  let jsonTo = await page.evaluate(async () => {
      const res = await fetch('/api/transfers?toWorld=11');
      return await res.json();
  });
  console.log('To Auroria:', Object.keys(jsonTo));
  console.log('To Auroria data:', jsonTo.data ? jsonTo.data.slice(0,1) : jsonTo);
  
  let jsonFrom = await page.evaluate(async () => {
      const res = await fetch('/api/transfers?fromWorld=11');
      return await res.json();
  });
  console.log('From Auroria:', Object.keys(jsonFrom));
  
  await page.goto('https://rubinot.com.br/killstats');
  let jsonKills = await page.evaluate(async () => {
      const res = await fetch('/api/killstats?world=11');
      return await res.json();
  });
  console.log('Killstats:', Object.keys(jsonKills));
  console.log('Killstats data:', jsonKills.data ? jsonKills.data.slice(0,1) : jsonKills.slice(0,1));
  
  await browser.close();
})();
