'use strict';

import { supabase } from '../db.js';
import puppeteer from 'rebrowser-puppeteer'; // Usando fork anti-detecção

import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { fileURLToPath } from 'url';
import os from 'os';
import { updateSheetRow } from '../lib/googleSheets.js';
import { findUniversalChrome, getLeanChromeArgs, getDebugScreenshotPath, cleanStaleLocks } from '../lib/storageGuardian.js';

/**
 * Decodifica chave Base32 padrão (RFC 4648)
 */
function base32Decode(base32) {
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
  let cleaned = (base32 || '').toUpperCase().replace(/=+$/, '').replace(/\s+/g, '');
  let bits = '';
  for (let i = 0; i < cleaned.length; i++) {
    const val = alphabet.indexOf(cleaned[i]);
    if (val === -1) continue;
    bits += val.toString(2).padStart(5, '0');
  }
  const bytes = [];
  for (let i = 0; i + 8 <= bits.length; i += 8) {
    bytes.push(parseInt(bits.substr(i, 8), 2));
  }
  return Buffer.from(bytes);
}

/**
 * Gera código TOTP de 6 dígitos para Google Authenticator (RFC 6238)
 */
function generateTOTP(secret, timeStep = 30) {
  if (!secret) return '';
  const key = base32Decode(secret);
  const epoch = Math.floor(Date.now() / 1000);
  const time = Math.floor(epoch / timeStep);
  const timeBuf = Buffer.alloc(8);
  timeBuf.writeBigInt64BE(BigInt(time));
  const hmac = crypto.createHmac('sha1', key).update(timeBuf).digest();
  const offset = hmac[hmac.length - 1] & 0x0f;
  const binary = ((hmac[offset] & 0x7f) << 24) |
                 ((hmac[offset + 1] & 0xff) << 16) |
                 ((hmac[offset + 2] & 0xff) << 8) |
                 (hmac[offset + 3] & 0xff);
  const otp = (binary % 1000000).toString().padStart(6, '0');
  return otp;
}




async function updateSheetIfApplicable(invite, updates) {
  if (invite.requested_by && invite.requested_by.includes('Linha')) {
    const matches = [...invite.requested_by.matchAll(/Linha (\d+)/g)];
    for (const match of matches) {
      if (match && match[1]) {
        await new Promise(r => setTimeout(r, 1000)); await updateSheetRow(parseInt(match[1]), updates);
      }
    }
  }
}

// ==========================================
// CONFIGURAÇÕES DA PLANILHA E CONTAS PADRÃO
// ==========================================
const DEFAULT_SHEET_URL = 'https://docs.google.com/spreadsheets/d/11ODx6WKc8qrlp_QLffMLgn9M95o42JiDhgUnG1w9K5Y/export?format=csv';

const WORLD_IDS = {
  auroria: '11',
  belaria: '15',
  bellum: '30',
  drakaria: '33',
  eldrian: '31',
  elysian: '1',
  'infernum i': '35',
  'infernum ii': '35',
  'infernum iii': '35',
  infernum: '35',
  lunarian: '9',
  malveria: '34',
  mystian: '18',
  obsidian: '32',
  solarian: '12',
  tenebrium: '21',
  vesperia: '16'
};

const DEFAULT_ACCOUNTS = {
  vesperia: { world: 'Vesperia', account_name: 'pifot16+maker9182@gmail.com', password: 'Liususu!28@', guild_name: 'Battlestorm Vesperia' },
  auroria: { world: 'Auroria', account_name: 'pifot16+maker781272@gmail.com', password: 'Liususu!28@3', guild_name: 'Shellpatrocina' },
  bellum: { world: 'BELLUM', account_name: 'pifot16+mak3r78372@gmail.com', password: 'Liusas!2asd', guild_name: 'Battlestorm Bellum' },
  belaria: { world: 'Belaria', account_name: 'pifot16+guizera@gmail.com', password: 'Ljajhsj@J7172', guild_name: 'Battlestorm Belaria' },
  tenebrium: { world: 'Tenebrium', account_name: 'pifot16+rubinot2@gmail.com', password: '88100267hH**', guild_name: 'Battlestorm Retro' },
  malveria: { world: 'Malveria', account_name: 'pifot16+grim@gmail.com', password: 'Kx3ngjasjd!2', guild_name: 'Battlestorm Malveria' },
  drakaria: { world: 'Drakaria', account_name: 'pifot16+intermedio@gmail.com', password: '88100267hH**', totp_secret: 'URFXIS2DFW75OJXU', guild_name: 'Warfire Leidorasga' }
};

/**
 * Parser customizado de linha CSV com tratamento de aspas duplas
 */
function parseCsvLine(line) {
  const result = [];
  let current = '';
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    if (char === '"') {
      inQuotes = !inQuotes;
    } else if (char === ',' && !inQuotes) {
      result.push(current.trim());
      current = '';
    } else {
      current += char;
    }
  }
  result.push(current.trim());
  return result;
}

/**
 * Busca convites diretamente da Planilha do Google configurada
 */
async function syncGoogleSheetInvites() {
  const sheetUrl = process.env.GOOGLE_SHEET_URL || DEFAULT_SHEET_URL;
  if (!sheetUrl) return;

  try {
    let csvUrl = sheetUrl;
    if (sheetUrl.includes('/edit')) {
      csvUrl = sheetUrl.replace(/\/edit.*$/, '/export?format=csv');
    } else if (!sheetUrl.includes('export?format=csv')) {
      csvUrl = DEFAULT_SHEET_URL;
    }

    const response = await fetch(csvUrl, { signal: AbortSignal.timeout(15000) });
    if (!response.ok) return;

    const csvText = await response.text();
    const lines = csvText.split('\n').filter(Boolean);
    if (lines.length <= 1) return;

    let addedCount = 0;

    for (let i = 1; i < lines.length; i++) {
      const cols = parseCsvLine(lines[i]);

      // Mapeamento das Colunas da Planilha:
      // B (index 1) = Sistema ("invite")
      // C (index 2) = Nome do Personagem (Pode ser separado por vírgula)
      // D (index 3) = Status de Processamento ("Pendente", "", "Concluido", "Finalizado")
      // F (index 5) = Status do Invite ("Processado", "Sucesso", etc.)
      // G (index 6) = Servidor de Origem/Destino ("Auroria", "Belaria", etc.)
      const sistema = (cols[1] || '').replace(/"/g, '').trim().toLowerCase();
      const rawChar = (cols[2] || '').replace(/"/g, '').trim();
      const statusD = (cols[3] || '').replace(/"/g, '').trim().toLowerCase();
      const statusF = (cols[5] || '').replace(/"/g, '').trim().toLowerCase();
      const servidor = (cols[6] || '').replace(/"/g, '').trim() || 'Auroria';

      const isPending = statusD === 'pendente';
      const currentReqBy = `Linha ${i + 1}`;

      if ((sistema === 'invite' || sistema === '') && rawChar && isPending) {
        const charList = rawChar.split(',').map(c => c.trim()).filter(Boolean);

        for (const charName of charList) {
          const { data: existing } = await supabase
            .from('guild_invites_queue')
            .select('id, status, requested_by')
            .ilike('character_name', charName)
            .ilike('world', servidor)
            .maybeSingle();

          if (!existing) {
            await supabase.from('guild_invites_queue').insert({
              character_name: charName,
              world: servidor,
              guild_name: 'Shell',
              status: 'PENDING',
              requested_by: currentReqBy
            });
            addedCount++;
          } else {
            let newReqBy = existing.requested_by || '';
            if (!newReqBy.includes(currentReqBy)) {
              newReqBy += (newReqBy ? ', ' : '') + currentReqBy;
            }
            
            await supabase.from('guild_invites_queue').update({
              status: 'PENDING',
              requested_by: newReqBy
            }).eq('id', existing.id);
            addedCount++;
          }
        }
      }
    }

    if (addedCount > 0) {
      console.log(`[AutoInvite] 📊 ${addedCount} novos convites importados da Planilha Google para o Supabase!`);
    }
  } catch (err) {
    console.error('[AutoInvite] Erro ao sincronizar Planilha do Google:', err.message);
  }
}

// ==========================================
// LÓGICA DE CÓPIA DE PERFIL DO LAUNCHER
// ==========================================
const RUBINOT_PROFILE = path.join(os.homedir(), 'AppData', 'Local', 'rubinot-launcher', 'EBWebView');
const WORK_PROFILE_BASE = fileURLToPath(new URL('../../worker_profiles', import.meta.url));

function copyDirSafe(src, dest) {
  if (!fs.existsSync(dest)) fs.mkdirSync(dest, { recursive: true });
  let files;
  try { files = fs.readdirSync(src); } catch { return; }
  for (const file of files) {
    const srcPath = path.join(src, file);
    const destPath = path.join(dest, file);
    try {
      const stat = fs.statSync(srcPath);
      if (stat.isDirectory()) {
        copyDirSafe(srcPath, destPath);
      } else {
        fs.copyFileSync(srcPath, destPath);
      }
    } catch { /* arquivo bloqueado, pula */ }
  }
}

function ensureProfile(world) {
  const profileDest = path.join(WORK_PROFILE_BASE, `launcher_${world.toLowerCase()}`);
  if (!fs.existsSync(profileDest)) {
    fs.mkdirSync(profileDest, { recursive: true });
  }
  return profileDest;
}

/**
 * Detecta e clica no widget do Cloudflare Turnstile usando coordenadas reais do mouse (CDP)
 */
async function solveTurnstileIfPresent(page, maxAttempts = 6) {
  for (let i = 0; i < maxAttempts; i++) {
    const tsFrame = page.frames().find(f => f.url().includes('challenges.cloudflare.com') || f.url().includes('turnstile'));
    if (tsFrame) {
      try {
        const frameEl = await tsFrame.frameElement();
        if (frameEl) {
          const box = await frameEl.boundingBox();
          if (box && box.width > 0) {
            await page.mouse.click(box.x + 28, box.y + box.height / 2);
            await new Promise(r => setTimeout(r, 1200));
            return true;
          }
        }
      } catch {}
    }
    await new Promise(r => setTimeout(r, 1000));
  }
  return false;
}

const LOCK_FILE = path.join(process.cwd(), '.invite_processing.lock');

function acquireLock() {
  try {
    // O flag 'wx' falha se o arquivo já existe — lock atômico
    fs.writeFileSync(LOCK_FILE, String(process.pid), { flag: 'wx' });
    return true;
  } catch {
    // Verificar se o processo dono do lock ainda está vivo
    try {
      const pid = parseInt(fs.readFileSync(LOCK_FILE, 'utf8'));
      try { process.kill(pid, 0); return false; } // processo ainda vivo
      catch { fs.unlinkSync(LOCK_FILE); return acquireLock(); } // processo morto, remove lock
    } catch { return false; }
  }
}

function releaseLock() {
  try { fs.unlinkSync(LOCK_FILE); } catch {}
}

/**
 * Executa o processamento de convites de guilda pendentes na fila com particionamento distribuído
 */
export async function runProcessAutoInvites() {
  if (!supabase) return;

  if (!acquireLock()) {
    console.log('[AutoInvite] Já existe um lote em processamento nesta máquina. Ignorando gatilho simultâneo.');
    return;
  }

  // Identificação do Worker atual
  let workerId = process.env.WORKER_ID;
  try {
    const idFile = path.join(process.cwd(), 'worker_id.txt');
    if (!workerId && fs.existsSync(idFile)) workerId = fs.readFileSync(idFile, 'utf8').trim();
  } catch {}
  workerId = workerId || `Worker-${os.hostname()}`;

  const targetWorlds = process.env.TARGET_WORLDS 
    ? process.env.TARGET_WORLDS.split(',').map(w => w.trim().toLowerCase()) 
    : null;

  console.log(`[AutoInvite] 🔍 [${workerId}] Verificando fila de convites pendentes...`);

  try {
    // 0. Sincronizar planilha do Google
    await syncGoogleSheetInvites();

    // Destrava convites que ficaram presos em IN_PROGRESS há mais de 3 minutos
    const staleTime = new Date(Date.now() - 3 * 60000).toISOString();
    await supabase.from('guild_invites_queue')
      .update({ status: 'PENDING', error_message: null })
      .eq('status', 'IN_PROGRESS')
      .lt('updated_at', staleTime);

    // 1. Buscar convites pendentes
    const { data: pendingInvites, error: fetchErr } = await supabase
      .from('guild_invites_queue')
      .select('*')
      .eq('status', 'PENDING')
      .order('created_at', { ascending: true })
      .limit(150);

    if (fetchErr) {
      console.error('[AutoInvite] Erro ao consultar fila de convites:', fetchErr.message);
      return;
    }

    if (!pendingInvites || pendingInvites.length === 0) {
      return;
    }

    console.log(`[AutoInvite] 📋 Encontrados ${pendingInvites.length} convites pendentes na fila global.`);

    // 2. Agrupar por Mundo/Servidor
    const invitesByWorld = {};
    for (const invite of pendingInvites) {
      const worldKey = (invite.world || 'Auroria').trim();
      if (!invitesByWorld[worldKey]) invitesByWorld[worldKey] = [];
      invitesByWorld[worldKey].push(invite);
    }

    // 3. Processar cada mundo isoladamente com claim atômico
    const chromeExe = findUniversalChrome();
    
    for (const [world, invites] of Object.entries(invitesByWorld)) {
      const worldKey = world.toLowerCase();
      if (targetWorlds && !targetWorlds.includes(worldKey)) {
        console.log(`[AutoInvite] ⏭️ Pulando ${world} (não atribuído a TARGET_WORLDS deste worker).`);
        continue;
      }

      // TRAVA ATÔMICA DISTRIBUÍDA: tenta reivindicar os convites pendentes deste mundo no Supabase
      const pendingIds = invites.map(i => i.id);
      const { data: claimedInvites, error: claimErr } = await supabase
        .from('guild_invites_queue')
        .update({
          status: 'IN_PROGRESS',
          error_message: `Assumido por ${workerId}`,
          updated_at: new Date().toISOString()
        })
        .in('id', pendingIds)
        .eq('status', 'PENDING')
        .select();

      if (!claimedInvites || claimedInvites.length === 0) {
        console.log(`[AutoInvite] ⏩ Mundo '${world}' já foi assumido por outro worker ativo da frota.`);
        continue;
      }

      console.log(`\n[AutoInvite] 🌐 [${workerId}] assumiu com exclusividade o mundo: ${world} (${claimedInvites.length} convites)`);

      let leaderAcc = null;
      const { data: dbAcc } = await supabase
        .from('guild_leader_accounts')
        .select('*')
        .ilike('world', world)
        .maybeSingle();

      if (dbAcc) {
        leaderAcc = dbAcc;
      } else {
        const defaultKey = world.toLowerCase();
        leaderAcc = DEFAULT_ACCOUNTS[defaultKey] || null;
      }

      if (!leaderAcc) {
        console.log(`[AutoInvite] ⏳ Mundo '${world}' ainda não possui conta de líder cadastrada. Mantendo na fila como 'Em breve...' para processamento futuro.`);

        for (const inv of invites) {
          if (inv.error_message !== 'Em breve...') {
            await supabase
              .from('guild_invites_queue')
              .update({ status: 'PENDING', error_message: 'Em breve...', updated_at: new Date().toISOString() })
              .eq('id', inv.id);
            await updateSheetIfApplicable(inv, { statusD: 'Pendente', statusF: 'Em breve (Aguardando ativação)' });
          }
        }
        continue;
      }

      const profilePath = ensureProfile(world);
      cleanStaleLocks(profilePath);

      console.log(`[PUPPETEER] Abrindo navegador silencioso em segundo plano para ${world}...`);
      const browser = await puppeteer.launch({
        headless: 'new', // 100% silencioso e invisível: sem janela física e sem ícone na barra de tarefas
        executablePath: chromeExe || undefined,
        userDataDir: profilePath,
        args: getLeanChromeArgs([
          '--window-size=1280,800',
          '--exclude-switches=enable-automation'
        ]),
        ignoreDefaultArgs: ['--enable-automation'],
      });

      try {
        const pages = await browser.pages();

        const page = pages.length > 0 ? pages[0] : await browser.newPage();
        await page.setViewport({ width: 1280, height: 800 });
        await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36');

        
        // Login no RubinOT
        const totpSecret = leaderAcc.totp_secret || DEFAULT_ACCOUNTS[world.toLowerCase()]?.totp_secret;
        console.log(`[AutoInvite] 🔑 Efetuando login no RubinOT (${world}) com a conta: ${leaderAcc.account_name}...`);
        const loggedIn = await loginRubinot(page, leaderAcc.account_name, leaderAcc.password, totpSecret);

        if (loggedIn === 'MAINTENANCE') {
          console.warn('[AutoInvite] 🔧 RubinOT em manutenção. Revertendo lote e aguardando o site voltar...');
          await browser.close().catch(() => {});
          const allPendingIds = pendingInvites.map(i => i.id);
          await supabase.from('guild_invites_queue')
            .update({ status: 'PENDING', error_message: 'Site em manutenção (RubinOT)', updated_at: new Date().toISOString() })
            .in('id', allPendingIds);
          releaseLock();
          return; // Para tudo
        }

        if (!loggedIn) {
          const errMsg = `Falha ao realizar login na conta '${leaderAcc.account_name}' no RubinOT.`;
          console.error(`[AutoInvite] ❌ ${errMsg} O sistema tentará novamente no próximo ciclo.`);

          for (const inv of claimedInvites) {
            await updateSheetIfApplicable(inv, { statusD: 'Pendente', statusF: 'Site Lento (Aguardando Retentativa)' });
            await supabase.from('guild_invites_queue')
              .update({ status: 'PENDING', error_message: errMsg, updated_at: new Date().toISOString() })
              .eq('id', inv.id);
          }
          await browser.close().catch(() => {});
          continue; // Pula para o próximo mundo
        }

        for (const inv of claimedInvites) {
          await updateSheetIfApplicable(inv, { statusD: 'Processando', workerE: workerId });
        }

        // Processar cada convite deste mundo reivindicado com exclusividade
        for (const invite of claimedInvites) {
          let guildTarget = leaderAcc.guild_name || invite.guild_name || process.env.GUILD_NAME || 'Shellpatrocina';
          if (guildTarget.toLowerCase() === 'shell') guildTarget = leaderAcc.guild_name || 'Shellpatrocina';
          console.log(`[AutoInvite] ✉ Enviando convite para '${invite.character_name}' na guilda '${guildTarget}' (${world})...`);

          console.log(`[AutoInvite] Aguardando 4 segundos entre convites...`);
          await new Promise(r => setTimeout(r, 4000));
          const result = await inviteCharacter(page, world, guildTarget, invite.character_name);

          if (result.success) {
            console.log(`[AutoInvite] ✅ Sucesso: ${invite.character_name} convidado!`);
            await supabase
              .from('guild_invites_queue')
              .update({ status: 'SUCCESS', error_message: result.reason || null, updated_at: new Date().toISOString() })
              .eq('id', invite.id);
            await updateSheetIfApplicable(invite, { statusD: 'Finalizado', statusF: result.reason ? `Sucesso: ${result.reason}` : 'Sucesso' });
          } else {
            console.error(`[AutoInvite] ❌ Falha (${invite.character_name}): ${result.reason}`);
            
            if (result.reason.includes('permiss')) {
              console.warn(`[AutoInvite] ⚠️ A conta líder para ${world} não possui permissões de convite na guilda '${guildTarget}'. Pausando este mundo.`);
              const worldIds = claimedInvites.map(i => i.id);
              await supabase
                .from('guild_invites_queue')
                .update({ status: 'PENDING', error_message: 'Sem permissao de convite na guilda (verifique se e Lider/Vice)', updated_at: new Date().toISOString() })
                .in('id', worldIds);
              break;
            }

            const isTempError = result.reason.includes('timeout') || 
                                result.reason.includes('Formul') || 
                                result.reason.includes('Input de convite') || 
                                result.reason.includes('503') ||
                                result.reason.includes('Cloudflare') ||
                                result.reason.includes('Turnstile');

            if (isTempError) {
               // Erro temporário (site engasgou ou Cloudflare) - Mantém pendente para o próximo ciclo!
               console.log(`[AutoInvite] 🔄 Retentativa agendada para '${invite.character_name}' (${result.reason}).`);
               await supabase
                 .from('guild_invites_queue')
                 .update({ status: 'PENDING', error_message: result.reason, updated_at: new Date().toISOString() })
                 .eq('id', invite.id);
               await updateSheetIfApplicable(invite, { statusD: 'Pendente', statusF: 'Site Lento (Aguardando Retentativa)' });
            } else {
               // Erro definitivo (já tem guilda, não existe, etc) - Falha e encerra
               await supabase
                 .from('guild_invites_queue')
                 .update({ status: 'FAILED', error_message: result.reason, updated_at: new Date().toISOString() })
                 .eq('id', invite.id);
               await updateSheetIfApplicable(invite, { statusD: 'Finalizado', statusF: 'Erro: ' + result.reason });
            }
          }
        }
      } finally {
        try {
          const pid = browser.process()?.pid;
          await browser.close().catch(() => {});
          if (pid && process.platform === 'win32') {
            try { process.kill(pid, 0); process.kill(pid); } catch {}
          }
        } catch {}
        cleanStaleLocks(profilePath);
      }
    }
  } catch (err) {
    console.error('[AutoInvite] Erro inesperado ao processar convites:', err.message);
  } finally {
    releaseLock();
  }
}

/**
 * Função de auxílio para Login no RubinOT
 */
async function loginRubinot(page, accountName, password, totpSecret = null) {
    try {
      await page.goto('https://rubinot.com.br/login', { waitUntil: 'networkidle2', timeout: 30000 }).catch(e =>
        console.error('[AutoInvite] Aviso de timeout no /login, prosseguindo...'));

      // Verificar se o site está em manutenção
      const currentUrl = page.url();
      const contentAfterNav = await page.content();
      if (currentUrl.includes('/maintenance') || contentAfterNav.includes('Maintenance Mode') || contentAfterNav.includes('Server is under maintenance') || contentAfterNav.includes("We'll Be Right Back")) {
        console.warn('[AutoInvite] 🔧 Site em manutenção! Pausando processamento...');
        return 'MAINTENANCE';
      }

      // Verificar se já está logado (o perfil do Chrome pode ter a sessão salva)
      const alreadyLoggedIn = contentAfterNav.includes('Minha Conta') || contentAfterNav.includes('>Sair<') || contentAfterNav.includes('Logado como');
      if (alreadyLoggedIn) {
        console.log(`[AutoInvite] ✅ Sessão já ativa para ${accountName} (cookie salvo).`);
        return true;
      }

      // Esperar o campo de email aparecer (React pode demorar a montar)
      const emailSelector = 'input[type="email"], input[name="email"], input[id="email"]';
      const passSelector = 'input[type="password"], input[name="password"], input[id="password"]';
      
      let foundEmail = await page.waitForSelector(emailSelector, { visible: true, timeout: 8000 }).catch(() => null);

      if (!foundEmail) {
        // Se não achou o email de imediato, pode ser tela de verificação humana do Cloudflare
        console.log('[AutoInvite] 🛡️ Verificando desafio Cloudflare inicial...');
        await solveTurnstileIfPresent(page, 8);
        foundEmail = await page.$(emailSelector);
      }

      if (foundEmail) {
        // Fechar banner de cookies se existir para não cobrir elementos
        try {
          await page.evaluate(() => {
            const btns = Array.from(document.querySelectorAll('button'));
            const aceitar = btns.find(b => b.innerText.includes('Aceitar') || b.innerText.includes('Essenciais'));
            if (aceitar) aceitar.click();
          });
        } catch {}

        await new Promise(r => setTimeout(r, 600));
        await page.click(emailSelector, { clickCount: 3 });
        await page.type(emailSelector, accountName, { delay: 35 });
        await page.click(passSelector, { clickCount: 3 });
        await page.type(passSelector, password, { delay: 35 });
        await new Promise(r => setTimeout(r, 500));

        await page.evaluate(() => {
          const form = document.querySelector('form');
          const btn = form?.querySelector('button[type="submit"], button') || document.querySelector('button[type="submit"]');
          if (btn) btn.click();
        });

        // Esperar resolução do Cloudflare Turnstile pós-submit ou navegação (até 15s)
        for (let i = 0; i < 15; i++) {
          await new Promise(r => setTimeout(r, 1000));

          await solveTurnstileIfPresent(page, 1);

          const curUrl = page.url();
          if (curUrl.includes('/account') || curUrl.includes('/my-account')) break;

          const content = await page.content().catch(() => '');
          if (content.includes('Minha Conta') || content.includes('>Sair<') || content.includes('Logado como')) break;
          if (curUrl.includes('/maintenance') || content.includes('Maintenance Mode')) break;

          // Se encontrar campo de 2FA / Autenticador
          const has2fa = await page.$('input[name="code"], input[name="two_factor"], input[name="two_factor_code"], input[name="otp"], input[name="token"], input[placeholder*="código" i], input[placeholder*="code" i], input[inputmode="numeric"]').catch(() => null);
          if (has2fa) break;
        }

        // Se houver desafio de Autenticação em 2 Etapas (Google Authenticator / TOTP)
        const otpSelector = 'input[name="code"], input[name="two_factor"], input[name="two_factor_code"], input[name="otp"], input[name="token"], input[placeholder*="código" i], input[placeholder*="code" i], input[inputmode="numeric"], input[type="text"][maxlength="6"]';
        const otpField = await page.$(otpSelector).catch(() => null);

        if (otpField) {
          if (totpSecret) {
            const token = generateTOTP(totpSecret);
            console.log(`[AutoInvite] 🔐 Desafio 2FA detectado para ${accountName}. Preenchendo código TOTP: ${token}...`);
            await page.click(otpSelector, { clickCount: 3 });
            await page.type(otpSelector, token, { delay: 40 });
            await new Promise(r => setTimeout(r, 600));

            await page.evaluate(() => {
              const form = document.querySelector('form');
              const submitBtn = form?.querySelector('button[type="submit"], button') || 
                                Array.from(document.querySelectorAll('button')).find(b => 
                                  /verificar|confirmar|entrar|validar|enviar|submit/i.test(b.innerText)
                                );
              if (submitBtn) submitBtn.click();
            });

            for (let i = 0; i < 15; i++) {
              await new Promise(r => setTimeout(r, 1000));
              await solveTurnstileIfPresent(page, 1);
              const curUrl = page.url();
              if (curUrl.includes('/account') || curUrl.includes('/my-account')) break;
              const content = await page.content().catch(() => '');
              if (content.includes('Minha Conta') || content.includes('>Sair<') || content.includes('Logado como')) break;
            }
          } else {
            console.error(`[AutoInvite] ⚠️ A conta ${accountName} exige autenticação 2FA, mas nenhum secret TOTP foi configurado!`);
            await page.screenshot({ path: getDebugScreenshotPath('debug_2fa_missing_secret.png') }).catch(() => {});
            return false;
          }
        }

        await new Promise(r => setTimeout(r, 1500));
      } else {
        const curUrl = page.url();
        const content = await page.content().catch(() => '');
        if (curUrl.includes('/maintenance') || content.includes('Maintenance Mode') || content.includes('Server is under maintenance') || content.includes("We'll Be Right Back")) {
          console.warn('[AutoInvite] 🔧 Site em manutenção detectado (redirecionado de /login)!');
          return 'MAINTENANCE';
        }
        console.error(`[AutoInvite] ⚠️ Campos de login não encontrados para ${accountName}. Tentando screenshot...`);
        await page.screenshot({ path: getDebugScreenshotPath('debug_login_form.png') }).catch(() => {});
        return false;
      }

      // Verificar se está logado após submeter
      const pageContent = await page.content();
      if (page.url().includes('/maintenance') || pageContent.includes('Maintenance Mode')) {
        console.warn('[AutoInvite] 🔧 Site em manutenção detectado após submissão!');
        return 'MAINTENANCE';
      }

      const isLoggedIn = pageContent.includes('Minha Conta') || pageContent.includes('>Sair<') || pageContent.includes('Logado como');

      if (!isLoggedIn) {
        await page.screenshot({ path: getDebugScreenshotPath('debug_login_fail.png') }).catch(() => {});
        console.error(`[AutoInvite] ❌ Login falhou para ${accountName} (sessão não detectada).`);
        return false;
      }

      console.log(`[AutoInvite] ✅ Login confirmado para ${accountName}.`);
      return true;
    } catch (err) {
      const curUrl = page.url();
      const content = await page.content().catch(() => '');
      if (curUrl.includes('/maintenance') || content.includes('Maintenance Mode') || content.includes('Server is under maintenance') || content.includes("We'll Be Right Back")) {
        console.warn('[AutoInvite] 🔧 Site em manutenção detectado durante erro de navegação!');
        return 'MAINTENANCE';
      }
      console.error('[AutoInvite] Erro durante o login:', err.message);
      return false;
    }

  }

/**
 * Função de auxílio para Convidar Personagem na Guilda
 */
async function inviteCharacter(page, world, guildName, characterName) {
  try {
    // 1. Ir para a página de gerenciar guilda diretamente (ou apenas reutilizar se já estiver nela)
    const encodedGuild = encodeURIComponent(guildName);
    const targetUrl = `https://rubinot.com.br/guilds/${encodedGuild}/manage`;
    if (!page.url().includes(`/guilds/${encodedGuild}/manage`)) {
      await page.goto(targetUrl, { waitUntil: 'domcontentloaded', timeout: 30000 });
      await new Promise(r => setTimeout(r, 1500));
    }

    // Fechar banner de cookies se existir
    await page.evaluate(() => {
      const btns = Array.from(document.querySelectorAll('button'));
      const aceitar = btns.find(b => b.innerText.includes('Aceitar') || b.innerText.includes('Essenciais'));
      if (aceitar) aceitar.click();
    });
    await new Promise(r => setTimeout(r, 300));

    // Clicar na aba Convidar
    await page.evaluate(() => {
      const btns = Array.from(document.querySelectorAll('button'));
      const btn = btns.find(b => b.innerText.trim() === 'Convidar');
      if (btn) btn.click();
    });
    await new Promise(r => setTimeout(r, 1500));

    // Digitar personagem
    const input = await page.$('input[placeholder="Nome do personagem"]');
    if (!input) {
       await page.screenshot({ path: getDebugScreenshotPath('debug_input_missing.png') }).catch(() => {});
       return { success: false, reason: 'Input de convite não encontrado na página (verifique permissões).' };
    }
    
    await input.click({ clickCount: 3 });
    await input.type(characterName, { delay: 80 });
    await new Promise(r => setTimeout(r, 500));

    // Clicar botão Convidar
    await page.evaluate(() => {
      const inp = document.querySelector('input[placeholder="Nome do personagem"]');
      if (inp) {
        const parent = inp.closest('form') || inp.parentElement;
        const btn = parent?.querySelector('button[type="submit"], button');
        if (btn) btn.click();
      }
    });

    // Esperar processamento do Cloudflare e resposta da página
    for (let i = 0; i < 15; i++) {
        await new Promise(r => setTimeout(r, 1000));
        
        await solveTurnstileIfPresent(page, 1);
        
        // Vamos buscar frases exatas no texto da página para caso a UI tenha funcionado
        const pageText = await page.evaluate(() => document.body.innerText.toLowerCase());
        
        if (pageText.includes('has been invited') || pageText.includes('foi convidado') || pageText.includes('sucesso')) {
            return { success: true };
        }
        
        if (pageText.includes('não existe') || pageText.includes('nao existe') || pageText.includes('does not exist') || 
            pageText.includes('player not found') || pageText.includes('character not found') ||
            pageText.includes('does not live on the same world') || pageText.includes('not found')) {
              try {
                  const { fetchRubinotApi } = await import('../lib/rubinotScraper.js');
                  const charData = await fetchRubinotApi('/api/characters/' + encodeURIComponent(characterName));
                  if (charData && charData.character && charData.character.world) {
                      return { success: false, reason: `Personagem está no mundo ${charData.character.world}.` };
                  }
              } catch (e) {}
              return { success: false, reason: 'Char não existe' };
          }
        
        if (pageText.includes('already in a guild') || pageText.includes('already belongs') || pageText.includes('already a member of')) {
            return { success: true, reason: 'Já está na guilda' };
        }
        
        // Cuidado: a UI tem um título "Convites pendentes", por isso NÃO podemos buscar só pela palavra "pendente"
        if (pageText.includes('already been invited') || pageText.includes('já foi convidado') || pageText.includes('already invited')) {
            return { success: true, reason: 'Personagem já possui convite pendente.' };
        }
        
        if (pageText.includes('token is required') || pageText.includes('verification token')) {
            return { success: false, reason: 'Bloqueado pelo Cloudflare (Token is required).' };
        }
    }
    
    // Screenshot para debugar qual foi a mensagem real do site
    await page.screenshot({ path: getDebugScreenshotPath('debug_timeout.png') }).catch(() => {});
    return { success: false, reason: 'Cloudflare bloqueou a verificação (Turnstile) do convite.' };
  } catch (err) {
    return { success: false, reason: `Erro na navegação: ${err.message}` };
  }
}

