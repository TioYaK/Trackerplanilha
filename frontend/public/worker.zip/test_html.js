import puppeteer from 'puppeteer-extra';
import StealthPlugin from 'puppeteer-extra-plugin-stealth';
import fs from 'fs';
puppeteer.use(StealthPlugin());

(async () => {
  const browser = await puppeteer.launch({headless: true});
  const page = await browser.newPage();
  
  await page.goto('https://rubinot.com.br/killstats');
  await new Promise(r => setTimeout(r, 2000));
  fs.writeFileSync('killstats.html', await page.content());
  
  await page.goto('https://rubinot.com.br/transfers');
  await new Promise(r => setTimeout(r, 2000));
  fs.writeFileSync('transfers.html', await page.content());
  
  await browser.close();
})();
