import puppeteer from 'puppeteer-extra';
import StealthPlugin from 'puppeteer-extra-plugin-stealth';
import * as cheerio from 'cheerio';
puppeteer.use(StealthPlugin());

(async () => {
  const browser = await puppeteer.launch({headless: true});
  const page = await browser.newPage();
  await page.goto('https://rubinot.com.br/deaths?world=Auroria');
  let html = await page.content();
  console.log('Deaths:', html.includes('Auroria'));
  
  await page.goto('https://rubinot.com.br/killstats?world=Auroria');
  html = await page.content();
  console.log('Killstats:', html.includes('Auroria'));
  
  await page.goto('https://rubinot.com.br/transfers?world=Auroria');
  html = await page.content();
  console.log('Transfers:', html.includes('Auroria'));
  
  await browser.close();
})();
