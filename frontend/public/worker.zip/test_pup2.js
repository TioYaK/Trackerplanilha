import puppeteer from 'puppeteer-extra';
import StealthPlugin from 'puppeteer-extra-plugin-stealth';
import * as cheerio from 'cheerio';
puppeteer.use(StealthPlugin());

(async () => {
  const browser = await puppeteer.launch({headless: true});
  const page = await browser.newPage();
  
  await page.goto('https://rubinot.com.br/transfers', {waitUntil: 'networkidle2'});
  
  const selects = await page.$$('select');
  if (selects.length > 1) {
      await selects[1].select('11'); 
      await page.waitForNavigation({waitUntil: 'networkidle2'}).catch(() => page.waitForTimeout(2000));
      let $ = cheerio.load(await page.content());
      console.log('Arriving:', $('table tbody tr').slice(0, 2).map((i, r) => $(r).text().trim().replace(/\s+/g, ' ')).get());
  }
  await browser.close();
})();
